import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';

const archivos = new Map([
  ['/', ['index.html', 'text/html; charset=utf-8']],
  ['/index.html', ['index.html', 'text/html; charset=utf-8']],
  ['/estilos.css', ['estilos.css', 'text/css; charset=utf-8']],
  ['/vista.mjs', ['vista.mjs', 'text/javascript; charset=utf-8']],
  ['/plan.mjs', ['plan.mjs', 'text/javascript; charset=utf-8']],
  ['/sugerencias.json', ['sugerencias.json', 'application/json; charset=utf-8']],
]);

createServer(async (peticion, respuesta) => {
  const ruta = new URL(peticion.url, 'http://127.0.0.1').pathname;
  const archivo = archivos.get(ruta);
  if (peticion.method !== 'GET' || !archivo) {
    respuesta.writeHead(404).end('Recurso ausente');
    return;
  }
  try {
    const bytes = await readFile(new URL(archivo[0], import.meta.url));
    respuesta.writeHead(200, { 'Content-Type': archivo[1], 'Cache-Control': 'no-store' }).end(bytes);
  } catch {
    respuesta.writeHead(404).end('Recurso ausente');
  }
}).listen(4173, '127.0.0.1', () => console.log('Abre http://127.0.0.1:4173 en el navegador.'));
