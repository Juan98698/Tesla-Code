// Copia aquí tus funciones aprobadas de la ruta, junto con sus auxiliares.
// Escribe primero las que necesita tu primer incremento y exporta sus nombres.
// Ejemplo de conexión cuando modeloPlan ya esté disponible:
// export { modeloPlan };
