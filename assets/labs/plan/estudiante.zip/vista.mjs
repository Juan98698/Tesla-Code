// Implementa la interfaz por etapas con las indicaciones de cada lección.
// 1. Importa tu regla modeloPlan y renderiza sus datos en #resultado.
// 2. Escucha submit. Separa los campos recibidos, la validación y el render.
// 3. Despacha las acciones del registro, guarda y prueba la restauración.
// 4. Añade búsqueda de sugerencias, error recuperable y cancelación.
