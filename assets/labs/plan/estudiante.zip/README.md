# Construye Mi plan de práctica

Abre la carpeta en un editor. Usa la línea de Node con soporte de tu instalación,
por ejemplo Node 24 LTS. Ejecuta `node servidor.mjs` y abre
http://127.0.0.1:4173. Ctrl+C detiene el servidor. Cada equipo usa sus propios
datos locales. El archivo no necesita instalar bibliotecas.

El formulario y los estilos son un andamio editable. `plan.mjs` y `vista.mjs`
empiezan con instrucciones. Trabaja con las actividades de los bloques 13 a 18.

1. Extrae funciones comprobadas de tu entrega TeslaCode a `plan.mjs`. Exporta
   `modeloPlan` y añade pruebas de 29, 30 y 60. Ejecuta `node --test`.
2. Revisa el HTML, su orden de teclado, sus etiquetas y la vista estrecha.
   Importa tus reglas desde `vista.mjs` para mostrar las líneas del informe.
3. Atiende `submit` con botón y Enter. Para errores, conserva el resultado previo
   y activa un mensaje visible. Registra sesiones y verifica que deshacer
   funciona también en vacío.
4. Guarda sesiones con la versión de copia 1. Prueba recarga, una copia válida y
   otra inválida. Exporta el texto que acepta `restaurarSesiones`.
5. Consulta `sugerencias.json` con fetch. Distingue éxito, fallo de HTTP, JSON
   inválido y cancelación de una búsqueda anterior. Ensaya cada caso en tu
   navegador y anota el resultado.
6. Repite en 320 px y escritorio. Compara contra el laboratorio de referencia
   y documenta una incidencia con un dato que la reproduce. Entrega tus
   archivos, pruebas y notas. Para publicar, sube la parte estática a un
   alojamiento HTTPS y comprueba la URL de tu versión.

La consola de TeslaCode contrasta el comportamiento de las reglas de cada reto.
Tu prueba de navegador contrasta la interfaz, los archivos y las APIs del sitio.
